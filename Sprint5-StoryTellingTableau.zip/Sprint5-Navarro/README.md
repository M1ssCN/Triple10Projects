Sprint 5 project - Storytelling with data
below is the link for the Tableau project.

https://public.tableau.com/views/Sprint5-CristalNavarro/OverallReturns?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link