This is the link (Revised) for the Final Project- Tableau Dashboard
Company: Zomato

https://public.tableau.com/views/CristalNFinalSprint/ZomatoRestaurants?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link
